<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.5" name="lunar1b_tileset_visual" tilewidth="32" tileheight="32" tilecount="308" columns="22">
 <image source="../lunar1b_tileset_visual.png" width="704" height="448"/>
 <wangsets>
  <wangset name="lunar" type="corner" tile="26">
   <wangcolor name="" color="#ff0000" tile="26" probability="1"/>
   <wangtile tileid="25" wangid="0,0,0,1,0,0,0,0"/>
   <wangtile tileid="26" wangid="0,0,0,1,0,1,0,0"/>
   <wangtile tileid="27" wangid="0,0,0,0,0,1,0,0"/>
   <wangtile tileid="47" wangid="0,1,0,1,0,0,0,0"/>
   <wangtile tileid="49" wangid="0,0,0,0,0,1,0,1"/>
   <wangtile tileid="69" wangid="0,1,0,1,0,1,0,0"/>
   <wangtile tileid="71" wangid="0,0,0,1,0,1,0,1"/>
   <wangtile tileid="92" wangid="0,1,0,1,0,1,0,1"/>
   <wangtile tileid="113" wangid="0,1,0,1,0,0,0,1"/>
   <wangtile tileid="115" wangid="0,1,0,0,0,1,0,1"/>
   <wangtile tileid="157" wangid="0,1,0,0,0,0,0,0"/>
   <wangtile tileid="158" wangid="0,1,0,0,0,0,0,1"/>
   <wangtile tileid="159" wangid="0,0,0,0,0,0,0,1"/>
  </wangset>
 </wangsets>
</tileset>
